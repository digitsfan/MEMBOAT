Simple scripts that produce a web page indicating that the script
just connects to and disconnects from the database.
