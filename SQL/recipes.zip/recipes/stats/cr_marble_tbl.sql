# cr_marble_tbl.sql

DROP TABLE IF EXISTS marble;
CREATE TABLE marble (i INT);
INSERT INTO marble (i) VALUES(1),(2),(3),(4),(5);
