The transaction.* scripts show how to implement transactions in various
languages.
