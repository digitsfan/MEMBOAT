# proto.sql

DROP TABLE IF EXISTS tbl_name;
#@ _CREATE_TABLE_
CREATE TABLE tbl_name
(
);
#@ _CREATE_TABLE_

SELECT * FROM tbl_name;
