<?php print ("I am a PHP program.\n"); ?>
