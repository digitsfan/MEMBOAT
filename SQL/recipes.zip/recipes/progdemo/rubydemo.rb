puts "I am a Ruby program."
