#!/usr/bin/perl
print "I am a Perl program.\n";
