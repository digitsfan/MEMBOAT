print("I am a Python program.")
