The numbering of the subdirectories is only to give a rough ordering
to them.  The numbers don't necessarily correspond to recipe numbers
in chapter 2.
